import React, { useEffect, useState } from "react";
import styles from "./index.module.css";
import Loading from "../Loading";
import useLogin from "../../api/useLogin";
import { useNavigate } from "react-router-dom";
import ModalPage from "../Modal UI";
import { useAuth } from "../../context/UserContext";

const LoginUI = () => {
  const api = useLogin();
  const navigate = useNavigate();
  const { setUserValue } = useAuth();

  const [modalOpen, setModalOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [loginData, setLoginData] = useState({
    email: null,
    password: null,
  });

  const onInputChange = (e) => {
    setLoginData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  const clearInput = () => {
    // console.log(document.getElementById("form-input"));
    // document.getElementById("form-input").reset();
    setLoginData({
      email: null,
      password: null,
    });
  };

  const login = async (e) => {
    e.preventDefault();
    setLoading(true);
    const apiData = await api.mutateLogin(loginData.email, loginData.password);
    setLoading(false);
    if (apiData?.status === 200) {
      localStorage.setItem("Name", apiData?.data?.Name);
      localStorage.setItem("Api Data", JSON.stringify(apiData));
      const fetched = localStorage.getItem("Api Data");
      setUserValue(JSON.parse(fetched));
      navigate("/dashboard");
    } else if (apiData?.status === 400) {
      clearInput();
      setModalOpen(true);
      navigate("/login");
    } else {
      navigate("/login");
    }
  };

  return (
    <>
      {loading ? (
        <ModalPage
          open
          content={
            <div>
              <Loading />
              Loading ...
            </div>
          }
          onClose={() => setLoading(false)}
        />
      ) : null}
      <div className="container d-flex flex-column justify-content-center " style={{ minHeight: "70vh" }}>
        <div className="row d-flex justify-content-around align-items-center">
          <div className="col-5">
            <p className={`mb-3 pt-2 mt-5 ${styles.access} col-12`}>Access My Account</p>
            <form id="form-input">
              {/* email */}
              <div className="col-12 mb-5 d-flex justify-content-center align-items-center">
                <div className="col-xxl-1 col-2 d-flex justify-content-start align-items-center">
                  <img src={"/assets/images/at.svg"} alt="img" />
                </div>
                <div className="col-10 col-xxl-11 d-flex align-items-center ">
                  <div className="d-flex flex-column align-items-start col-12">
                    <p className={`m-0 ${styles.access}`}>Email</p>
                    <input type="email" className="border-0 h-50 border-bottom" style={{ width: "100%", outline: "none" }} name="email" onChange={onInputChange} onPaste={onInputChange} />
                  </div>
                </div>
              </div>
              {/* password */}
              <div className="col-12 mb-3 d-flex justify-content-center align-items-center">
                <div className="col-2 col-xxl-1 d-flex justify-content-start align-items-center">
                  <img src={"/assets/images/lock.svg"} alt="img" />
                </div>
                <div className="col-10 col-xxl-11 d-flex align-items-center ">
                  <div className="d-flex flex-column align-items-start col-12">
                    <p className={`m-0 ${styles.access}`}>Password</p>
                    <input type="password" className="border-0 h-50 border-bottom" style={{ width: "100%", outline: "none" }} name="password" onChange={onInputChange} onPaste={onInputChange} />
                  </div>
                </div>
              </div>
              {/* remember me */}
              <div className="col-12 mb-4 d-flex justify-content-between align-items-center">
                <div className= {`${styles.rememInput} d-flex justify-content-start align-items-center gap-2`}>
                  <input type="checkbox" name="remember" id="remember" style={{ height: "14px", width: "14px" }} />
                  <p className={`${styles.remember} m-0`}>Remember me</p>
                </div>
                <div className="d-flex align-items-center justify-content-center ">
                  <p className={`${styles.remember} m-0`} style={{ textDecoration: "underline" }}>
                    Forgot your password?
                  </p>
                </div>
              </div>
              {/* login button */}
              <div className="col-12">
                <button type="submit" className={`text-white py-2 w-100 ${styles.loginBtn}`} onClick={login}>
                  Login
                </button>
              </div>
            </form>

            {/* Don’t have an account */}
            <div className="mt-3  d-flex align-items-center justify-content-center">
              <p className={`${styles.remember} m-0`} style={{ textDecoration: "underline" }}>
                Don’t have an account ? <span style={{ fontWeight: "700px" }}>Sign up. </span>
              </p>
            </div>
          </div>
        </div>
        {/* terms of service */}
        <div className="row d-flex justify-content-around align-items-center">
          <div className="mt-4  d-flex align-items-center justify-content-center col-8">
            <p className={`${styles.termsLine} m-0`}>
              By signing in or clicking "Login", you agree to our <span className={`${styles.privacy}`}>Terms of Service</span> Please also read our{" "}
              <span className={`${styles.privacy}`}>Privacy Policy</span>
            </p>
          </div>
        </div>
      </div>


      {/* new login page vinod */}
<div>
  <div className="container">
    <div className={styles.LoginMain}>
      <h4>Access My Account</h4>

      <div className={styles.EmailDiv}>
        <div className={styles.SvgEmail}>
        <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40" fill="none">
  <path d="M19.9848 30.5419C17.8968 30.5419 15.8557 29.9228 14.1196 28.7628C12.3835 27.6027 11.0304 25.9539 10.2314 24.0249C9.43231 22.0958 9.22324 19.9731 9.63059 17.9253C10.0379 15.8774 11.0434 13.9963 12.5198 12.5198C13.9963 11.0434 15.8774 10.0379 17.9253 9.63059C19.9731 9.22324 22.0958 9.43231 24.0249 10.2314C25.9539 11.0304 27.6027 12.3835 28.7628 14.1196C29.9228 15.8557 30.5419 17.8968 30.5419 19.9848C30.5387 22.7838 29.4254 25.4671 27.4462 27.4462C25.4671 29.4254 22.7838 30.5387 19.9848 30.5419ZM19.9848 10.6008C18.1288 10.6008 16.3145 11.1511 14.7713 12.1823C13.2281 13.2134 12.0253 14.679 11.3151 16.3937C10.6048 18.1084 10.419 19.9953 10.7811 21.8156C11.1432 23.6359 12.0369 25.308 13.3493 26.6204C14.6617 27.9328 16.3338 28.8265 18.1541 29.1886C19.9744 29.5507 21.8613 29.3649 23.576 28.6546C25.2907 27.9444 26.7563 26.7416 27.7874 25.1984C28.8186 23.6552 29.3689 21.8408 29.3689 19.9848C29.366 17.4969 28.3764 15.1118 26.6171 13.3525C24.8579 11.5933 22.4728 10.6037 19.9848 10.6008Z" fill="black"/>
  <path d="M19.9848 39.9257C17.2507 39.9217 14.5464 39.3576 12.0387 38.2682C9.53097 37.1788 7.27307 35.5871 5.40423 33.5914C1.85827 29.8151 -0.0790108 24.8071 0.00246991 19.6275C0.0839506 14.448 2.1778 9.50341 5.84079 5.8405C9.50378 2.17758 14.4484 0.0838363 19.628 0.00246337C24.8075 -0.0789096 29.8155 1.85848 33.5917 5.40452C35.5875 7.27315 37.1792 9.53093 38.2686 12.0385C39.3581 14.5462 39.9221 17.2504 39.926 19.9845C39.935 22.3178 39.5313 24.6344 38.7336 26.8272C38.3316 27.8886 37.5701 28.7753 36.5816 29.333C35.5932 29.8907 34.4404 30.0841 33.3241 29.8794C32.2078 29.6747 31.1986 29.0849 30.4724 28.2127C29.7461 27.3406 29.3487 26.2414 29.3495 25.1064V10.0139H30.5225V25.1064C30.5229 25.9649 30.8238 26.7963 31.373 27.4562C31.9221 28.1161 32.685 28.563 33.5291 28.7194C34.3733 28.8757 35.2456 28.7317 35.9947 28.3123C36.7438 27.8929 37.3225 27.2245 37.6304 26.4231C38.3813 24.3599 38.7613 22.1801 38.7529 19.9845C38.7494 17.4108 38.2184 14.8652 37.1928 12.5048C36.1672 10.1443 34.6688 8.0191 32.7899 6.26023C29.2365 2.91863 24.5216 1.09177 19.6443 1.16671C14.7671 1.24165 10.1106 3.21251 6.66144 6.66171C3.21231 10.1109 1.24155 14.7675 1.16672 19.6447C1.09188 24.522 2.91885 29.2368 6.26053 32.7902C7.96344 34.618 10.0147 36.0867 12.2936 37.1099C14.5725 38.1332 17.0331 38.6903 19.5305 38.7486C22.0279 38.8068 24.5118 38.365 26.8359 37.4491C29.1601 36.5332 31.2776 35.1618 33.0638 33.4154L33.8849 34.2542C30.1707 37.8885 25.1813 39.9243 19.9848 39.9257Z" fill="black"/>
</svg>
        </div>

        <div className={styles.LabelEmail}>
          <label>
            Email Address
          </label> <br/>
          <input type="text"/>
        </div>

      </div>


      <div className={`${styles.EmailDiv} ${styles.passwardDiv}`}>
        <div className={styles.SvgEmail}>
        <svg xmlns="http://www.w3.org/2000/svg" width="28" height="37" viewBox="0 0 28 37" fill="none">
  <path d="M14.0002 31.5418C14.4445 31.5418 14.805 31.1785 14.805 30.7309V27.081C16.0843 26.6889 17.0183 25.49 17.0183 24.0746C17.0183 22.3421 15.6191 20.9323 13.8996 20.9323C12.1801 20.9323 10.7809 22.3421 10.7809 24.0746C10.7809 25.563 11.8143 26.8102 13.1954 27.1329V30.7305C13.1954 31.1785 13.5559 31.5418 14.0002 31.5418ZM12.3906 24.0746C12.3906 23.2361 13.0678 22.5541 13.8996 22.5541C14.7314 22.5541 15.4086 23.2361 15.4086 24.0746C15.4086 24.913 14.7314 25.595 13.8996 25.595C13.0678 25.595 12.3906 24.913 12.3906 24.0746ZM27.1952 21.6755C27.6394 21.6755 28 21.3122 28 20.8646V17.8497C28 16.0661 26.5598 14.615 24.7892 14.615H22.1832V8.2461C22.1832 3.69935 18.512 0 13.9998 0C9.48759 0 5.81682 3.69935 5.81682 8.2461V14.6154H3.21082C1.44062 14.6154 0 16.0665 0 17.8501V33.7653C0 35.5489 1.44022 37 3.21082 37H24.7892C26.5594 37 28 35.5489 28 33.7653V25.8655C28 25.4178 27.6394 25.0546 27.1952 25.0546C26.7509 25.0546 26.3904 25.4178 26.3904 25.8655V33.7653C26.3904 34.6545 25.6721 35.3782 24.7892 35.3782H3.21082C2.32834 35.3782 1.60963 34.6549 1.60963 33.7653V17.8497C1.60963 16.9605 2.32793 16.2368 3.21082 16.2368H24.7892C25.6717 16.2368 26.3904 16.9601 26.3904 17.8497V20.8646C26.3904 21.3126 26.7509 21.6755 27.1952 21.6755ZM20.5739 14.6154H7.42645V8.2461C7.42645 4.59337 10.3753 1.62181 14.0002 1.62181C17.6251 1.62181 20.5739 4.59337 20.5739 8.2461V14.6154Z" fill="black"/>
</svg>
        </div>

        <div className={styles.LabelEmail}>
          <label>
          Password
          </label> <br/>
          <input type="text"/>
        </div>

      </div>


      <div className={`${styles.ReCheck}`}>
        <div className={`${styles.RememMe} ${styles.rememInput}`}>
          <input type="checkbox"/>
        Remember me
        </div>

        <div className={styles.Forget}>
        Forgot your password?
        </div>

      </div>

      <div className={styles.ButtonLogin}>
        <a href="#">LOGIN</a>
      </div>

      <div className={styles.SignUpW}>
        <p>Don’t have an account ?  <span>Sign up.</span></p>
      </div>


      <div className={styles.PolicyA}>
        <p>By signing in or clicking "Login", you agree to our <span>Terms of Service </span> Please also read our<span> Privacy Policy </span></p>
      </div>




    </div>
  </div>

</div>


      {/* new login page vinod */}
      {modalOpen ? (
        <ModalPage
          open={modalOpen}
          content={
            <>
              <h2>Warning</h2>
              <p className="mt-3">Invalid Credentials!</p>
              <div className="d-flex justify-content-center">
                <button className={styles.closeButton} onClick={() => setModalOpen(false)}>
                  OK
                </button>

                {/* <button className={Styles.modalClose} onClick={onClose}>
                CANCEL
              </button> */}
              </div>
            </>
          }
          onClose={() => setModalOpen(false)}
        />
      ) : (
        ""
      )}
    </>
  );
};

export default LoginUI;
